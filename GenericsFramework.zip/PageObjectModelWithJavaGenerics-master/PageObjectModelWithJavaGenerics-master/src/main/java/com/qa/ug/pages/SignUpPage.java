package com.qa.ug.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignUpPage extends BasePage

{
	public SignUpPage(WebDriver driver, WebDriverWait wait) {
		super(driver, wait);
}
}
